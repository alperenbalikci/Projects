const cartItem = document.querySelector(".cart-items-container");
const navbar = document.querySelector(".navbar");


/*buttons*/
const cartBtn = document.querySelector("#cart-btn");
const packagesBtn = document.querySelector("#packages-btn");


cartBtn.addEventListener("click", function () {
    cartItem.classList.toggle("active");
    document.addEventListener("click", function (e) {
      if (
        !e.composedPath().includes(cartBtn) &&
        !e.composedPath().includes(cartItem)
      ) {
        cartItem.classList.remove("active");
      }
    });
  });

  packagesBtn.addEventListener("click", function () {
    navbar.classList.toggle("active");
    document.addEventListener("click", function (e) {
      if (
        !e.composedPath().includes(packagesBtn) &&
        !e.composedPath().includes(navbar)
      ) {
        navbar.classList.remove("active");
      }
    });
  });

  function calculatePrice() {
    const course = document.getElementById("course").value;
    const hours = parseInt(document.getElementById("hours").value);

    const prices = {
        matematik: 1000,
        edebiyat: 800,
        cografya: 650,
        tarih: 750
    };

    const pricePerHour = prices[course];
    const totalPrice = pricePerHour * hours;


    document.getElementById("total-price").textContent = totalPrice + " TL";
}